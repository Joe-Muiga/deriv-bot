# Deploy: Scout + Follower (phone guide)

**Render env vars to add**
- `SCOUT_FOLLOWER_ENABLED=1`
- `DERIV_SCOUT_TOKEN` = demo token A (or keep `DERIV_API_TOKEN`)
- `DERIV_FOLLOWER_TOKEN` = demo token B (only needed for `demo` mode)
- `FOLLOWER_MODE=shadow` first, later `demo`
- Keep `RENDER_API_KEY`, `RENDER_SERVICE_ID`, `DERIV_ACCOUNT_MODE=demo`
- NEVER set `FOLLOWER_LIVE_CONFIRM` in this phase.

**Order**
1. Run `shadow` for a few hours (no token B needed).
2. Switch to `demo` once the logs look sane.

**Watch in logs** (search `SF REPORT`)
- `GATE OPEN/CLOSED` + reason, win rate vs breakeven 47.17%
- `GATED pnl` vs `ALWAYS-FOLLOW` = the number that says if the gate helps
- `scout wr gate-ON vs gate-OFF` = gate quality
- `FOLLOWER[...] bal` starts at $10,000
- `SF_EVENT,{...}` lines = raw settled events (copy for offline analysis)

**Dashboard**: the normal home page now shows the Scout+Follower panel at the top (`/sf/view` = panel alone, `/sf` = JSON)

**Red flags**: `FOLLOWER NOT STARTED`, `could not connect`, `PERSISTENCE NOT CONFIGURED`, `skipped` counters all growing with `taken` 0.


---
## Update: regime gate + ML + strict 3m45s redeploy

**What changed**
- Fixed leg->cooldown cycle is OFF (`FIXED_CYCLE_ENABLED=False`). No cooldowns anywhere.
- Scout redeploys every `REDEPLOY_INTERVAL_SECS=225` (3 min 45 s), forever. It drains open
  Scout AND Follower contracts, saves state to Render env vars (waits for it), then fires the hook.
  After the hook fires the old instance takes no new entries (`REDEPLOY_HANDOFF_PAUSE`).
- Gate = `regime_gate.RegimeGate` (`GATE_MODE=regime`; set `GATE_MODE=edge` to go back to the old one).
  HOT when 4 of the last 6 Scout results won, the last one won and the last-12 win rate >= 55%.
  COLD after 2 straight losses, or <=3 of last 6 wins, or equity -2R from peak, or 150 s with no result.
- ML: `online_learner.py` (logistic model of P(win), learns from every confirmed Scout result,
  vetoes entries only when trained AND proven better than baseline) and `auto_tuner.py`
  (every 60 results replays the last 400 through nearby gate settings, adopts only walk-forward-validated gains,
  and raises `no_edge` which makes the Follower stand aside).
- Follower: $2.08 start (`FOLLOWER_START_BALANCE`). Fixed bug: 10% exposure cap of $2 = $0.21 < $0.35 min stake
  blocked EVERY entry; the cap now always allows one stake.

**New env var**: `SF_ML_STATE` (written by the bot). If the Follower balance on your dashboard is stale, delete
`SF_FOLLOWER_STATE` once so it restarts from `FOLLOWER_START_BALANCE`.

**Watch** (`SF REPORT`): `REGIME HOT/COLD heat x/6`, `ML ... useful=`, `TUNER ... no_edge=`, `skipped ml/noedge`.
Tests: `python test_regime.py`, `python test_edge_follower.py`.


---
## Update: HMM regime engine (Oct 2 2026)

- Gate engine is now `REGIME_ENGINE=hmm` (default). Set `REGIME_ENGINE=rules` on Render to roll back to the counting rules.
- First ~40 Scout results: the gate stays closed while it learns (state persists across the 3m45s redeploys).
- **Watch** (`SF REPORT`): `HMM P(hot)=.. forecast .. vs breakeven .. edge ..pt | fit p_hot= p_cold= session~..s regimes_real=`.
  `regimes_real=False` = the zig-zag is not statistically distinguishable from noise right now; the gate sits out on purpose.
- `HMM FIT #n` log lines show each time the model changes its mind about whether regimes exist.
- Tuning knobs (config / env): `HMM_ENTER_MARGIN`, `HMM_LR_MIN` (higher = stricter proof of regimes), `HMM_REFIT_EVERY`,
  `HMM_FIT_WINDOW`, `ML_TUNE_EVERY`. The tuner moves the margins by itself.
- Delete `SF_ML_STATE` once if you want the learner to start clean (it resets itself automatically because its feature set changed).
- Test: `python test_hmm.py` (about 1-2 min).
